import RenderRouter from "routes/index";

const App = () => {
  return <RenderRouter />;
};

export default App;
