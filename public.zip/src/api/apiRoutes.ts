//User module
export const LOGIN = 'user/login';
export const REGISTER = 'user/register';
export const FORGOT_PASSWORD = 'user/forgotPassword';
export const UPDATEPROFILE = 'user/updateProfile';
export const VIEWPROFILE = 'user/viewProfile';
export const CHANGEPASSWORD = 'user/changePassword';