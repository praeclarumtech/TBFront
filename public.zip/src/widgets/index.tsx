// import widget/custom components from highlight-code fold
import PageHeading from "./PageHeading";
import { StatRightTopIcon } from "./stats/StatRightTopIcon";

export {
  PageHeading,
  StatRightTopIcon,
};
