// src/store/slices/index.ts
export { setPersonalDetails, resetPersonalDetails } from './personalDetailsSlice';
export { setEducationalDetails } from './educationalDetailsSlice';
export { setJobDetails, resetJobDetails } from './jobDetailsSlice';
