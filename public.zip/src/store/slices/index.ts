// src/store/slices/index.ts
export { setPersonalDetails, resetPersonalDetails } from './personalDetailsSlice';
export { setEducationalDetails, resetEducationalDetails } from './educationalDetailsSlice';
export { setJobDetails, resetJobDetails } from './jobDetailsSlice';
