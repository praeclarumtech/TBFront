

import { DashboardMenuProps } from "types";
import { v4 as uuid } from "uuid";


export const DashboardMenu: DashboardMenuProps[] = [
  {
    id: uuid(),
    title: "Dashboard",
    icon: "home",
    link: "/",
  },
  {
    id: uuid(),
    title: "Applicants",
    grouptitle: true,
  },
  {
    id: uuid(),
    title: "Applicants",
    icon: "layers",

    link: '/applicants'
  },

  // {
  //   id: uuid(),
  //   title: "Add Applicant",
  //   icon: "layout",
  //   link: "/add_applicants",
  // },
  {
    id: uuid(),
    title: "Analysis",
    grouptitle: true,
  },
  {
    id: uuid(),
    title: "Email",
    icon: "monitor",
    link: '/email',
  },

  {
    id: uuid(),
    title: "Reports",
    icon: "corner-left-down",
    link: '/reports',
  },
  {
    id: uuid(),
    title: "Masters",
    grouptitle: true,
  },
{
    id: uuid(),
    title: "Years",
    icon: "monitor",
    link: '/passingYear',
  },

  {
    id: uuid(),
    title: "Skills",
    icon: "corner-left-down",
    link: '/skills',
  },
  

];