export interface PassingYearData {
  _id: string;
  year: number;
}
